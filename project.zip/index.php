<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

define("callbackUrl", "http://localhost/vira/pgResponse.php");
?>

<!doctype>
<html>
<head>
    <meta charset="utf-8">
    <title>Samarth Distributors</title>
    <link rel="stylesheet" href= "style.css" type="text/css">
	
</head>
    <body class="theme-desktop light" style="background-color: rgba(252, 249, 249, 0.89);">
		
	<div class="content">
    <div class="color">
       <div class="logo">
           <img src="Shrinivas Nagmal 20220320_223050.jpg" alt="Logo Imgae" >
           <label id="text">Samarth Distributors</label><br>

           <div id="title">
            <h2>500+ Famous eBooks in Hindi -<br> स्पेशल ऑफर"</h2>
			<img src="book.jpg">
			
           </div>
       </div>
	   
	   <div class="sample">

	   <h3>सभी किताबें हिन्दी में </h3>
	   <h4>500+ Hindi Best-Seller eBooks in PDF @ just Rs. 99</h4>
	   <div class="eng">HURRY UP !!! - RS. 99 OFFER FOR ​LIMITED TIME ONLY</div>
	   <div class="ma"><p style="font-size: 15px ;">ऑफर केवल सीमित अवधि के लिए - "Pay" के बटन पर क्लिक करके इस पैक को केवल 99 रुपये में अभी प्राप्त करें। <br><br>
	        500 से भी ज़्यादा राष्ट्रीय व अंतर्राष्ट्रीय प्रसिद्ध किताबें, जो कि दुनियाभर के विश्वविख्यात लेखकों द्वारा लिखी गई हैं, आपको इस पैक में जीवनभर के लिए केवल 99 रुपये में दी जा रही हैं जिन्हें आप कभी भी अपने मोबाईल फोन में, टैब व iPad में या अपने कंप्युटर व लैपटॉप में जितनी बार चाहें उतनी बार डाउनलोड करके पढ़ सकते हैं तथा अपने मित्रों व परिवार के लोगों को दे सकते हैं।<br><br> ​
	        इन किताबों को पढ़कर आप ना केवल सफलता की राह पर चलना शुरू कर देंगे, बल्कि इस दुनिया के लिए एक चमकदार शख्सियत वाले एक महत्वपूर्ण, क्रांतिकारी इंसान के रूप में उभरकर आएंगे। आशा करते हैं कि हमारे द्वारा आपके समक्ष लायी गईं ये किताबें आपके जीवन को सकारात्मक रूप में बदलेंगी ।<br><br>
</p><b>List of eBooks (हिंदी अनुवाद में)</b><br>
	   
	   <p class ="hello">
	   <span class="moreText">
	  
•	The 5 AM Club (Hindi) - Robin Sharma<br><br>
•	Rich Dad's Guide to Investing Hindi Pdf<br><br>
•	Retire Young Retire Rich in Hindi<br><br>
•	ZERO TO ONE - Hindi Pdf<br><br>
•	How To Stop Worrying And Start Living<br><br>
•	Who Will Cry When you Die Hindi - Robin Sharma<br><br>
•	The Richest Man In Babylon Hindi - George Samuel Clason<br><br>
•	The Power Of Habit - Hindi<br><br>
•	The Intelligent Investor Hindi Pdf<br><br>
•	My Experiments with truth - Hindi Pdf<br><br>
•	The monk who sold his Ferrari - Hindi Pdf<br><br>
•	The Secret (Rhonda Byrne) Hindi Pdf<br><br>
•	Rich Dad Poor Dad Hindi Pdf<br><br>
•	THINK AND GROW RICH PDF<br><br>
•	THE POWER OF YOUR SUBCONSCIOUS MIND HINDI<br><br>
•	Mindset - Hindi Book Pdf<br><br>
•	Logon ko 90-second mein Prabhavit karein<br><br>
•	12 rules for life Hindi Pdf<br><br>
•	Buffett & Graham Se Seekhen Share Market Mein (Hindi) pdf<br><br>
•	MANN KE CHAMATKAR - Miracles Of Mind - Hindi Pdf<br><br>
•	MAIN KAUN HOON - Swami Vivekanand<br><br>
•	Business of 21st century - 21 Vi Sadi Ka Vyvasaya - Robert T.Kiyosaki<br><br>
•	Badi Soch ka Bada Jadu - The Magic of Thinking Big - Hindi Pdf<br><br>
•	Turn Setbacks into Greenbacks - Mushkil Daur Mein Aage Badhane ke 7 Rahasya<br><br>
•	Lakshay (Goals) Hindi Pdf - Brian Tracy<br><br>
•	Hum Apko Ameer Kyon Banana Chahte Hain - Robert Kiyosaki , Donald Trump - Hindi<br><br>
•	Har Path Vijay Path - Napolean Hill Pdf<br><br>
•	Business School - Robert Kiyosaki Hindi Pdf<br><br>
•	One Percent formula - Hindi Pdf<br><br>
•	The Brief History of Time -Hindi- Stephen Hawking<br><br>
•	The 10X Rule Hindi Book<br><br>
•	7 Habits of Highly Effective people Hindi Pdf<br><br>
•	The 80 - 20 Principle Hindi<br><br>
•	How To Win Friends and Influence People - Hindi<br><br>
•	DHAN KO AAKARSHIT KAISE KAREN (Hindi)<br><br>
•	Lakshay - Goals By Brian Tracy Hindi<br><br>
•	Swayam Mein Vishwas Hindi Pdf<br><br>
•	Change your life in 24 hours<br><br>
•	Aap Bhi Leader ban sakte hain<br><br>
•	AAP khud hi best Hain – Anupam Kher<br><br>
•	Aisi vaani Boliye<br><br>
•	Amiri ki CHabi aapke haath mein<br><br>
•	Aapki Zindagi sirf ek minute mein Badal Sakti hai<br><br>
•	Beyond the power of your subconscious mind<br><br>
•	Bhagya ke rahasya<br><br>
•	Body Language<br><br>
•	Business Kohinoor – Ratan Tata<br><br>
•	Buland Irade, Nischt kamyabi<br><br>
•	Man’s Search for meaning<br><br>
•	The Magic – Rhonda Byrne<br><br>
•	Secrets of Millionaire Mind – T Harv Eker<br><br>
•	You can heal your life – Louise hay<br><br>
•	The four Agreement<br><br>
•	Eat that frog<br><br>
•	Success through a positive mental attitude<br><br>
•	Inner Engineering<br><br>
•	The Subtle art of not giving a fuck<br><br>
•	Sawaal hi Jawab hai – Questions are the Answers<br><br>
•	As a Man Thinketh<br><br>
•	Shrimad Bhagavad Gita<br><br>
•	Quran – Hindi<br><br>
•	Sapiens<br><br>
•	Achaa Bolne ki kalaa aur kamyaabi<br><br>
•	Chanakya Niti<br><br>
•	Kamyabi Unlimited<br><br>
•	Kade Pravachan<br><br>
•	Khud Se Prem Karo<br><br>
•	Leader ke 21 Anivarya Gun<br><br>
•	Logon ko Prabhavit Kaise Karein<br><br>
•	You can if you think you can – Buland Iraade Nischit Kamyaabi<br><br>
•	Atmavishwas<br><br>
•	Aapki Zindagi sirf ek minute mein badal sakti hai<br><br>
•	The Leader who had no title<br><br>
•	Invincible Thinking<br><br>
•	Sakaratmak Soch Apaar Shakti<br><br>
•	Jeevan jeene ki kalaa – Dalai Lama<br><br>
•	The Laws of happiness<br><br>
•	Samay ka prabandhan<br><br>
•	Samvaad ka jadoo<br><br>
•	Jeetne ka nazariya<br><br>
•	Ishwar kya hai<br><br>
•	Beyond the power of your subconscious mind<br><br>
•	The Miracle of meditation<br><br>
•	Family wisdom<br><br>
•	Power of Now<br><br>
•	Practising the power of now<br><br>
•	Aap bhi leader ban sakte hain<br><br>
•	Anand ka Saral Marg<br><br>
•	Samriddha Banne ki Aseem Shakti<br><br>
•	Sukhi Jeevan ke 3 satya<br><br>
•	Eleven commandments of life<br><br>
•	24 ghante mein zindagi badlein<br><br>
•	The go getter – काम से कामयाबी तक<br><br>
•	The Greatness Guide<br><br>
•	The Greatness Guide 2<br><br>
•	The Mastery Manual<br><br>
•	Apani Aatmshakti ko pehchaanein<br><br>
•	Prabhavshaali Leadership ke sootra<br><br>
•	Leadership Wisdom<br><br>
•	Personality Plus<br><br>
•	Apne bheetar chupe Leader ko Kaise Jagayein<br><br>
•	Get Smart – Brian Tracy<br><br>
•	Mind Management<br><br>
•	Vijetaaon Ke 6 Nazariye<br><br>
•	Ameer Banne ke 13 Pakke Tarike<br><br>
•	Khud ko Heal Karne ke 111 Mantra<br><br>
•	Kamyabi Unlimited<br><br>
•	Forge your future - APJ Abdul Kalam<br><br>
•	Mera cheese Kisne hataya<br><br>
•	Prabhavshaali selling ke sutra<br><br>
•	Shikhar Par Milenge<br><br>
•	45 second mein presentation kaise dein<br><br>
•	Swayam mein vishwas<br><br>
•	The One Minute Manager<br><br>
•	Steve Jobs ki Tarah Kaise sochein<br><br>
•	Adhiktam Safaltaa<br><br>
•	Chanakya 7 secrets of Leadership<br><br>
•	Kabeer ke management sutra<br><br>
•	Chanakya in you<br><br>
•	Sapne dekhe khuli aankhon se<br><br>
•	Kautilya Arthshastra<br><br>
•	Dainik Prerna<br><br>
•	Practical steps to think and grow rich<br><br>
•	Super success ke golden rules<br><br>
•	Shakti - HINDI<br><br>
•	Soch Badlo Zindagi Badlo<br><br>
•	Daulat aur safaltaa ki raah<br><br>
•	The Secret Letters of the Monk who sold his ferrari<br><br>
•	Time Management<br><br>
•	I am Fine<br><br>
•	13 steps to bloody good marks<br><br>
•	13 करोड़पतियों की आदतें जिन्होंने खुद ही सब कुछ हासिल कर लिया है 100 Great Business Ideas Hindi<br><br>
•	101 Sadabahaar Kahaniyan (Deep Trivedi)<br><br>
•	A message to gracia<br><br>
•	A Selfmade Millonaire<br><br>
•	Aakhri Kitaab jo apki zindagi badal degi<br><br>
•	Aatm Vishwas aur Aatm Samman Badhayein<br><br>
•	Abraham Lincoln - Biography<br><br>
•	Albert Einstein - Biography<br><br>
•	Andrew Carnegie<br><br>
•	Benjamin Graham ki atmakatha<br><br>
•	Anant Chetna ki Khoj Mein - Michael A Singer<br><br>
•	Bhaktiyoga<br><br>
•	Corporate Chanakya<br><br>
•	Discover your destiny<br><br>
•	Gyanyog - Swami Vivekanad<br><br>
•	Hero- Rhondha Byrne<br><br>
•	Hum Honge Kamyaab<br><br>
•	Ikkisvi sadi ka lok vyavhaar<br><br>
•	Ishwar kya hai<br><br>
•	Kitaabe Ke Kuch Ansh-Hindi<br><br>
•	Careerchya Vividh Vata-Marathi <br><br>
•	Jaadu-Hindi <br><br>
•	Instagram Hashtag Tips & Tricks<br><br>
•	50 Business Ideas For The New Age Entrepreneur-English Pdf<br><br>
•	 Habit Staking –Enflish Pdf<br><br>
•	Network Marketing-Hindi Pdf<br><br>
•	 The Cancer<br><br>
•	The Anti-Cancer<br><br>
•	 1%  Formula<br><br>
•	Ek Ke Dyan se Sarv Ka Dyan<br><br>
•	How To make  64 Pieces of Content in a day<br><br>
•	Swami Dayanand<br><br>
•	Getting To Yes<br><br>
•	Jeet Aapki<br><br>
•	Biswarup Roy Chowdhari<br><br>
•	Life Changing Quiets<br><br>
•	Epubor<br><br>
•	Logonko Kaise Prabhavit Kiya Jay<br><br>
•	Universal Method Design<br><br>
•	Padho To Aise Padho<br><br>
•	Aakhir Jeet Humhari<br><br>
•	Inside Chanakya’s  Mind<br><br>
•	10000 Instagram Followers<br><br>
•	Hacking Instagram Follower<br><br>
•	Digital Marketing Analytics<br><br>
•	E-marketing<br><br>
•	Yog Suchi<br><br>
•	Kathinaiyo Mai Sambhavnai<br><br>
•	Sakaratmk Soch Ki Shakti<br><br>
•	Hindi Grammer<br><br>
•	Badi Soch ka Bada Jaadu<br><br>
•	The Wise Marchant<br><br>
•	Man Ke Chamtkar<br><br>
•	Himmat Hai –Kiran Bedi<br><br>
•	1001 Motivational Quotes for Success<br><br>
•	Bhashan Kala<br><br>
•	Aapke Avachetan Man Ki Shakti Se Aage<br><br>
•	Sandip Maheshwari ke Vichar<br><br>
•	The Law Of Attraction<br><br>
•	12th Fail-Anurag Pathak<br><br>
•	Accha Bolneki Kala Aur Kaamyabi<br><br>
•	Aakhiri Kitaab jo apki Zindagi badal de<br><br>
•	Life 50 Self-Help Kitaanto ka Saar<br><br>
•	Yog<br><br>
•	Tanav Mukhi ke Saral Upay<br><br>
•	How to Talk Anyone<br><br>
•	Jeevan Ke 365 Sabak<br><br>
•	  Marketing Management<br><br>
•	Har Din 24 Gante Kaise Jiye?<br><br>
•	Aalasi Logonke Liye Money Management<br><br>
•	Edu Teria Current Affairs<br><br>
•	Lekhak Ke Bare main<br><br>
•	Khulakar Khao Fhir Bhi Vajan Ghatao<br><br>
•	Judo Jodo Jeeto<br><br>
•	Indian Share Market For Beginners<br><br>
•	Samay Ka Prabhandhan<br><br>
•	 Samay Prabhandan Safalayta Ki Kunji<br><br>
•	English Grammer In Use 2<br><br>
•	 Ek Vijeta Ki Rananiti<br><br>
•	Chinta Chodo Sukh Se Jio<br><br>
•	Amir Bananeke 13 Pakke Tarike<br><br>
•	Atama Vishwas Aur Safalta<br><br>
•	Mahanta Ka Margdarshak<br><br>
•	Sacred Games<br><br>
•	Chankya Sutrani<br><br>
•	 Janiye Sasthe Mahange Ka Manovigyan<br><br>
•	Weight Loss Ka Tamasha<br><br>
•	Sharlok Home Ki Kahaniya<br><br>
•	Tanav Mukt Jivan Ke Rahasya<br><br>
•	Best Digital Marketing Guide<br><br>
•	Website Design and Development<br><br>
•	7 Dino Mai Bloging Sikhe<br><br>
•	McDonald's Success Story<br><br>
•	Secret Of Success<br><br>
•	Share Market Mai Invest Karana Sikhe Warren Buffet<br><br>
•	Secret Of Success<br><br>
•	 Happiness of Success<br><br>
•	Network Marketing Principle<br><br>
•	Importance Of Aspiration<br><br>
•	Sapanko Ka Vigyan 2<br><br>
•	Ratan Taata<br><br>
•	International YOGA Day<br><br>
•	Badi Badi Khushiyonke Choti Choti batein<br><br>
•	 Quick and Easy Way of Speaking<br><br>
•	 Sabse Mushkil Kam Sabase Pehale(Eat That Frog)<br><br>
•	Ayurvedh Saar Sangrah<br><br>
•	Dhyan Ke Chamatkar<br><br>
•	Devorce<br><br>
•	Ek Mahan Japani Guru<br><br>
•	Apaka USP Kya Hai<br><br>
•	Within 90 Sec Impress Peoples<br><br>
•	Ache Anak Paneke 13 Tarike<br><br>
•	Milakar Kam Karaneke<br><br>
•	Business Management Simplified<br><br>
•	Business Mai Safalta Ke 51 Sutra<br><br>
•	

+ 200 more life-changing Books<br>
	 _ _ _<br><br>
	 </span></p>
	   

	   <button class="read-more-btn">Read More</button><br><br>
	  <script src="script.js"></script>
	  
	  <br><a style="font-size:17px ;">
If you have any problem getting your downloadable file, don't worry at all.<br>

Just leave us an email and we will reply to you back on the same day.<br>

<b>Email: </b><a href="mailto:shrinivas.nagmal@gmail.com " style="font-size:17px;">shrinivas.nagmal@gmail.com</a><br>

<b>Mobile No:</b>7020276350<br><br>

Thank You<br> </a>

धन्यवाद <br><br><br>
<b style="font-size:20px ;">How to get all eBooks - eBooks प्राप्त करने का तरीका<br></b><br>
<p style="font-size:15 ;">
पेमेंट होने के बाद आपके सामने एक दूसरा पेज खुलेगा जिसपर डाउनलोड बटन होगा जिसे दबाकर आप सभी e-Books तुरंत डाउनलोड कर सकते हैं।<br><br>
इसके साथ ही भविष्य में कभी भी डाउनलोड करने के लिए आपको एक email भेजा जाएगा जिसमें इन सभी e-Books को डाउनलोड करने का लिंक होगा जिसे कभी भी क्लिक करके ये सभी eBooks प्राप्त की जा सकती हैं।<br><br>
आप उस email को हमेशा संभाल के अपने पास रख सकते हैं।<br><br>
अगर आपको डाउनलोड करने में कोई समस्या हो तो आप हमें नीचे दिए गये email या WhatsApp या Call भी कर सकते हैं।<br><br></p>
<a style="font-size:17px">
<b>Average delivery time</b><br><br>
After successful payment, you'll be redirected on next <b>download page</b> within just <b>10 seconds</b>
And within 10 min, you will get 1 email 
Contact us, if you have<br> any problem in downloading.

​</a>
	   
	  <br>
	  <br>
	 <!-- <img src="https://freepngimg.com/download/facebook/73463-icons-computer-facebook-signature-email-block.png" width="22px" height="22px" a href="#"></a>&nbsp;&nbsp
	  <img src="https://freepngimg.com/download/social_media/74116-vector-tulane-twitter-icons-media-university-computer.png" width="22px" height="22px" a href="#"></a>&nbsp;&nbsp;
	  <img src="https://freepngimg.com/download/whatsapp/77102-whatsapp-computer-call-telephone-icons-png-image-high-quality.png" width="25px" height="25px" a href="#"></a><br><br>;-->
	  <b>Contact Us</b><br><br>
	  <div class="email">
	  <img src="https://freepngimg.com/download/gmail/77580-webmail-address-mail-yahoo!-email-icon.png" width="22px" height="22px" a href="#"></a>&nbsp;&nbsp;&nbsp;<a href="mailto:webmaster@example.com" style="font-size:17px;"> shrinivas.nagmal@gmail.com</a><br><br>
	  <img src="https://freepngimg.com/download/telephone/63060-grown-now-computer-to-icons-many-telephone.png" width="18px" height="18px"a href="#"></a>&nbsp;&nbsp;&nbsp; 7020276350<br><br><br>
		</div>
		
		<a style="font-size:17px ;">
	   <b>Terms & Conditions:</b><br>
	   Disclaimer:<br><br><br>
	   NOT FACEBOOK: This site is not a part of the Facebook™ website or Facebook Inc. Additionally, This site is NOT endorsed by Facebook™ in any way. FACEBOOK is a trademark of FACEBOOK, Inc.<br><br>
	   Refund Policy:<br><br>
	   Since Digital Creatives is offering non-tangible irrevocable goods we do not issue refunds once the order is accomplished and the product is sent.<br><br>
	   As a customer, you are responsible for understanding this upon purchasing any item at our site.<br><br>
	   Please note that our bonuses are offered on behalf of our respected partners and are not an issue for a refund or chargeback. However, we realize that exceptional circumstances can take place with regard to the character of the product we supply.<br><br>
	   Love & Respect,<br>
	   Digital Creatives<br><br>
	   You agree to share information entered on this page with Digital Creatives (owner of this page) and Razorpay, adhering to applicable laws.<br><br><br><br>
		</a>
	   </div>
</div>
	   </div>

	   <div data-view-id="1" id="main-view" class="slider-view">

	   <form id="form" class="form-control" method="POST" action="pay.php" >
       <div class="container">
	    <div class="box" >
		<div class="payment"><h2>Payment Details</h2><br></div>
		
		
	      <label  class="sr-only">Offer Price</label>
	      <input type="text" id="TXN_AMOUNT" name="TXN_AMOUNT"" class="form-control" value="99" readonly><br><br><br>
		
		  <label  class="sr-only">Email</label>
	      <input id="EMAIL" type="text" name="EMAIL" class="form-control"  pattern="^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+))@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+))\.([A-Za-z]{2,})$"  required="" ><br><br><br>

		  <label   class="sr-only">Mobile no</label>
	      <input id="MSISDN" type="text"  name="MSISDN" class="form-control" pattern="^\d{10}[0-9]*$" required=""><br>


		  <div class="photo">
          <img src="https://cdn.razorpay.com/static/assets/pay_methods_branding.png">		  
		  </div>
		  
		 
		  <button class="btn" type="submit" name="submit" value="send" onClick="passvalues();"><b><span> Rs 99.00</span></b></button>

	      </div>
</div>
</div>
	   </div>
	</div>
</form>    
    </body>

</html>