<?php

$keyId = 'rzp_live_OYy6I35qj2ijQw';
$keySecret = 'm3Qp3mvHi7lGdHmWxwTPlGpX';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
